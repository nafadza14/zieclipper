import Link from 'next/link'
import { DashboardShell } from '@/components/dashboard/DashboardShell'
import { CREDIT_RATE, MIN_TOPUP, BONUS_TIERS, CREDIT_COST, creditsFromRupiah } from '@/server/credits'

// Docs page — how credits are consumed. Modeled on
// https://help.opus.pro/docs/article/how-are-credits-consumed
// Numbers pulled directly from server/credits.ts so this page never drifts
// from the actual billing logic.

export default function CreditsDocsPage() {
  return (
    <DashboardShell title="How credits are consumed" subtitle="Zieclipper credit system reference">
      <div className="max-w-3xl mx-auto space-y-8 text-neutral-300 leading-relaxed text-sm">

        <section>
          <h2 className="text-white text-lg font-bold mb-2">Ringkasan</h2>
          <p>
            Zieclipper pakai sistem <span className="text-white font-semibold">prepaid credit</span>. Anda top-up sekali,
            saldo dipakai per aksi. Kredit tidak kedaluwarsa.
          </p>
          <div className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-4 mt-3 flex items-center gap-3">
            <span className="text-3xl">🪙</span>
            <div>
              <div className="text-white font-semibold">10 kredit gratis saat registrasi</div>
              <div className="text-xs text-neutral-500">Cukup untuk 10 generate video pendek untuk mencoba.</div>
            </div>
          </div>
        </section>

        <section>
          <h2 className="text-white text-lg font-bold mb-2">Konsumsi per Aksi</h2>
          <p className="mb-3">
            Biaya kredit berskala berdasarkan panjang video sumber. Video pendek jauh lebih murah dari video panjang.
            Adil untuk casual creator, tetap sustainable untuk power user.
          </p>

          <div className="bg-[#0d0d16] border border-white/[0.06] rounded-xl overflow-hidden">
            <Row col1="Aksi" col2="Kredit" header />
            <Row col1="Generate video ≤ 10 menit" col2="1 kredit" />
            <Row col1="Generate video 10 – 30 menit" col2="2 kredit" />
            <Row col1="Generate video 30 – 60 menit" col2="3 kredit" />
            <Row col1="Generate video > 60 menit" col2="5 kredit" />
            <Row col1="Export MP4 (semua rasio)" col2="GRATIS" highlight />
            <Row col1={`Auto face tracking pada export`} col2={`+${CREDIT_COST.faceTrackingPerExport} kredit`} />
            <Row col1="Ganti bahasa transkrip (retranscript)" col2="GRATIS" highlight />
            <Row col1="Edit caption / preset / crop" col2="GRATIS" highlight />
            <Row col1="Publish ke YouTube Shorts" col2="GRATIS" highlight />
          </div>
        </section>

        <section>
          <h2 className="text-white text-lg font-bold mb-2">Kapan Kredit Dipotong</h2>
          <ul className="list-disc pl-5 space-y-1.5">
            <li>Kredit generate dipotong <span className="text-white">setelah kami tahu durasi video</span> (setelah download metadata YouTube atau upload selesai), bukan saat klik tombol.</li>
            <li>Kalau pipeline gagal di tengah jalan setelah pemotongan, kredit <span className="text-emerald-400">otomatis di-refund</span>.</li>
            <li>Kredit face tracking dipotong sebelum analisis dijalankan. Kalau saldo tidak cukup, export tetap berjalan dengan crop tetap.</li>
            <li>Video yang gagal di-generate (mis. URL invalid, YouTube memblokir, error server) <span className="text-white">tidak</span> memotong kredit.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-white text-lg font-bold mb-2">Top-Up</h2>
          <p className="mb-3">
            Rate dasar <span className="text-white font-semibold">Rp {CREDIT_RATE.toLocaleString('id-ID')} per kredit</span>.
            Minimum top-up <span className="text-white">Rp {MIN_TOPUP.toLocaleString('id-ID')}</span>. Anda bisa top-up nominal berapa pun di atas minimum,
            kredit dihitung otomatis. Kredit tidak expire.
          </p>

          <div className="bg-[#0d0d16] border border-white/[0.06] rounded-xl overflow-hidden">
            <div className="grid grid-cols-3 px-4 py-2 border-b border-white/[0.06] text-[10px] uppercase tracking-wider text-neutral-500 font-semibold">
              <div>Mulai dari</div>
              <div className="text-right">Bonus</div>
              <div className="text-right">Contoh dapat</div>
            </div>
            {BONUS_TIERS.map((t, i) => {
              const q = creditsFromRupiah(t.minRupiah)
              return (
                <div key={i} className="grid grid-cols-3 px-4 py-2.5 items-center text-sm border-t border-white/[0.04] first:border-t-0">
                  <div className="text-white">Rp {t.minRupiah.toLocaleString('id-ID')}</div>
                  <div className="text-right text-emerald-400 font-semibold">{t.bonusPct === 0 ? '-' : `+${t.bonusPct}%`}</div>
                  <div className="text-right text-neutral-300 font-mono text-xs">
                    {q.total} kredit
                    {q.bonus > 0 && <span className="text-emerald-400 ml-1">(+{q.bonus})</span>}
                  </div>
                </div>
              )
            })}
          </div>
          <p className="text-xs text-neutral-500 mt-3">
            Contoh di atas dihitung pada nominal minimum tiap tier. Top-up lebih besar dalam tier yang sama tetap dapat % bonus yang sama.
            <Link href="/settings#credits" className="text-white underline ml-1">Top-up sekarang →</Link>
          </p>
        </section>

        <section>
          <h2 className="text-white text-lg font-bold mb-2">Contoh Perhitungan</h2>
          <div className="bg-[#0d0d16] border border-white/[0.06] rounded-xl p-4 space-y-3">
            <Example
              title="Kreator kasual: 5 video/bulan"
              lines={[
                '5 video @ ~10 menit = 5 × 1 kredit = 5 kredit',
                'Export 10 klip 9:16 tanpa face-track = gratis',
                'Total: 5 kredit/bulan (Rp 14.000 top-up dapat 10 kredit, cukup 2 bulan)',
              ]}
            />
            <Example
              title="Kreator serius: 20 video/bulan"
              lines={[
                '15 video @ ~20 menit = 15 × 2 = 30 kredit',
                '5 video @ ~45 menit = 5 × 3 = 15 kredit',
                '10 export dengan face-track = 10 × 1 = 10 kredit',
                'Total: 55 kredit/bulan (Rp 75.000 dapat 58 kredit dengan bonus 10%)',
              ]}
            />
            <Example
              title="Agency: 100 video/bulan"
              lines={[
                '80 video @ 20-30 menit = 80 × 2 = 160 kredit',
                '20 video @ 45 menit = 20 × 3 = 60 kredit',
                '30 export dengan face-track = 30 × 1 = 30 kredit',
                'Total: 250 kredit/bulan (Rp 300.000 dapat 257 kredit dengan bonus 20%)',
              ]}
            />
          </div>
        </section>

        <section>
          <h2 className="text-white text-lg font-bold mb-2">FAQ</h2>
          <FAQ q="Apakah kredit expire?" a="Tidak. Kredit tetap di akun Anda selama akun aktif." />
          <FAQ q="Bisa refund top-up?" a="Kredit yang sudah masuk saldo tidak bisa di-refund ke Rupiah. Tapi kredit yang gagal terpakai (misal video corrupt, server error) otomatis kembali ke saldo." />
          <FAQ q="Kenapa video panjang lebih mahal?" a="Analisis AI membaca seluruh transkrip. Video 60 menit punya transkrip 6–10× lebih panjang dari video 10 menit, jadi butuh lebih banyak komputasi." />
          <FAQ q="Bisa transfer kredit ke teman?" a="Belum. Fitur gift & referral kredit di roadmap." />
          <FAQ q="Ada trial?" a="10 kredit gratis saat registrasi, cukup untuk 10 generate video pendek. Tidak ada trial berlangganan." />
        </section>

        <div className="text-center pt-4">
          <Link href="/settings#credits" className="inline-block bg-white text-black text-sm font-semibold rounded-full px-6 py-3 hover:bg-neutral-200 transition">
            🪙 Top-up kredit
          </Link>
        </div>
      </div>
    </DashboardShell>
  )
}

function Row({ col1, col2, header, highlight }: { col1: string; col2: string; header?: boolean; highlight?: boolean }) {
  return (
    <div className={`flex items-center px-4 py-2.5 ${!header ? 'border-t border-white/[0.04]' : ''} ${header ? 'bg-white/[0.03]' : ''}`}>
      <div className={`flex-1 ${header ? 'text-[10px] uppercase tracking-wider text-neutral-400 font-semibold' : 'text-white text-sm'}`}>
        {col1}
      </div>
      <div className={`text-sm font-mono font-semibold shrink-0 ${
        header ? 'text-[10px] uppercase tracking-wider text-neutral-400' :
        highlight ? 'text-emerald-400' : 'text-white'
      }`}>
        {col2}
      </div>
    </div>
  )
}

function Example({ title, lines }: { title: string; lines: string[] }) {
  return (
    <div>
      <div className="text-white text-sm font-semibold">{title}</div>
      <ul className="text-xs text-neutral-400 mt-1 space-y-0.5 pl-4 list-disc">
        {lines.map((l, i) => <li key={i}>{l}</li>)}
      </ul>
    </div>
  )
}

function FAQ({ q, a }: { q: string; a: string }) {
  return (
    <div className="border-t border-white/[0.04] py-3">
      <div className="text-white font-semibold text-sm mb-1">{q}</div>
      <div className="text-neutral-400 text-xs">{a}</div>
    </div>
  )
}
