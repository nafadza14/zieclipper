'use client'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { MarketingShell, MarketingPanel } from '@/components/marketing/MarketingShell'
import { useAuth } from '@/hooks/useAuth'
import { CREDIT_RATE, MIN_TOPUP, BONUS_TIERS, creditsFromRupiah } from '@/server/credits'
import { IconBolt, IconShield, IconSparkles } from '@/components/marketing/Icons'

export default function PricingPage() {
  const router = useRouter()
  const { user } = useAuth()
  return (
    <MarketingShell>
      <MarketingPanel
        title="Pricing"
        subtitle="Top-up sesuka Anda. Rp 1.400 per kredit, minimum Rp 14.000, bonus otomatis untuk top-up besar."
        wide
      >
        {/* Hero rate line */}
        <div className="bg-gradient-to-br from-amber-500/10 to-transparent border border-amber-500/20 rounded-xl p-4 text-center">
          <div className="text-[10px] uppercase tracking-wider text-amber-400/80 font-semibold">Rate dasar</div>
          <div className="text-white text-3xl md:text-4xl font-bold mt-1">
            Rp {CREDIT_RATE.toLocaleString('id-ID')}
            <span className="text-neutral-400 text-sm ml-2 font-normal">/ kredit</span>
          </div>
          <div className="text-[11px] text-neutral-500 mt-1">
            Minimum top-up Rp {MIN_TOPUP.toLocaleString('id-ID')} · kredit tidak expire
          </div>
        </div>

        {/* Bonus tier table */}
        <div className="mt-4">
          <div className="text-[10px] uppercase tracking-wider text-neutral-500 font-semibold mb-2">Bonus progresif</div>
          <div className="bg-white/[0.03] border border-white/[0.06] rounded-xl overflow-hidden">
            <div className="grid grid-cols-3 px-4 py-2 border-b border-white/[0.06] text-[10px] uppercase tracking-wider text-neutral-500 font-semibold">
              <div>Nominal top-up</div>
              <div className="text-right">Bonus</div>
              <div className="text-right">Contoh dapat</div>
            </div>
            {BONUS_TIERS.map((tier, i) => {
              const q = creditsFromRupiah(tier.minRupiah)
              return (
                <div key={i} className="grid grid-cols-3 px-4 py-2.5 items-center text-sm border-t border-white/[0.03] first:border-t-0">
                  <div className="text-white font-semibold">Rp {tier.minRupiah.toLocaleString('id-ID')}+</div>
                  <div className="text-right text-emerald-400 font-semibold">
                    {tier.bonusPct === 0 ? '—' : `+${tier.bonusPct}%`}
                  </div>
                  <div className="text-right text-neutral-300 text-xs font-mono">
                    {q.total} kredit
                    {q.bonus > 0 && <span className="text-emerald-400 ml-1">(+{q.bonus})</span>}
                  </div>
                </div>
              )
            })}
          </div>
          <div className="text-[10px] text-neutral-500 mt-2 text-center">
            Contoh dihitung dari nominal minimum tiap tier. Top-up lebih banyak = kredit lebih banyak plus bonus %.
          </div>
        </div>

        {/* Value pills */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-5">
          <ValueRow Icon={IconBolt} title="Fleksibel" body="Top-up nominal berapa pun mulai dari Rp 14.000. Cocok untuk casual maupun kreator harian." />
          <ValueRow Icon={IconSparkles} title="Bonus otomatis" body="Semakin besar top-up, bonus kredit otomatis dihitung, hingga 20% ekstra." />
          <ValueRow Icon={IconShield} title="Refund otomatis" body="Jika proses gagal karena masalah kami, kredit langsung kembali ke saldo Anda." />
        </div>

        <div className="text-center mt-6">
          <button
            onClick={() => user ? router.push('/settings#credits') : router.push('/auth')}
            className="bg-white text-black text-sm font-semibold rounded-full px-6 py-3 hover:bg-neutral-200 transition"
          >
            {user ? 'Top-up sekarang' : 'Daftar, dapat 10 kredit gratis'}
          </button>
          <div className="mt-2">
            <Link href="/docs/credits" className="text-neutral-400 hover:text-white text-xs underline">
              Lihat rincian konsumsi kredit
            </Link>
          </div>
        </div>
      </MarketingPanel>
    </MarketingShell>
  )
}

function ValueRow({ Icon, title, body }: { Icon: React.ComponentType<{ size?: number; className?: string }>; title: string; body: string }) {
  return (
    <div className="flex items-start gap-3 p-3 bg-white/[0.02] border border-white/[0.06] rounded-xl">
      <div className="w-8 h-8 rounded-lg bg-white/[0.05] border border-white/[0.06] flex items-center justify-center text-white shrink-0">
        <Icon size={16} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-white text-sm font-semibold">{title}</div>
        <div className="text-neutral-400 text-[11px] leading-relaxed">{body}</div>
      </div>
    </div>
  )
}
