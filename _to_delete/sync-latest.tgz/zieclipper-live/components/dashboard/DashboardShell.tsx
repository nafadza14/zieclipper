'use client'
import { Sidebar } from './Sidebar'

// Full-height SaaS layout: fixed left sidebar (240px on md+), main content
// scrolls independently in the remaining width. On mobile the sidebar is
// hidden (md:flex in Sidebar.tsx) so the page fills the width -- the mobile
// nav can be layered in later without changing consumers.
export function DashboardShell({
  title,
  subtitle,
  actions,
  children,
}: {
  title?: string
  subtitle?: React.ReactNode
  actions?: React.ReactNode
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen bg-[#050508] text-white">
      <Sidebar />
      <div className="md:pl-60">
        {(title || actions) && (
          <header className="sticky top-0 z-20 bg-[#050508]/85 backdrop-blur-xl border-b border-white/[0.06]">
            <div className="px-6 h-14 flex items-center gap-4">
              <div className="flex-1 min-w-0">
                {title && <h1 className="text-white text-sm font-semibold truncate">{title}</h1>}
                {subtitle && <div className="text-[11px] text-neutral-500 truncate">{subtitle}</div>}
              </div>
              {actions && <div className="flex items-center gap-2 shrink-0">{actions}</div>}
            </div>
          </header>
        )}
        <main className="px-6 py-8">{children}</main>
      </div>
    </div>
  )
}
