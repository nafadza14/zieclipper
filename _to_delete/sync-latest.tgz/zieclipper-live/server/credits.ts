import type { SupabaseClient } from '@supabase/supabase-js'

// Credit consumption table for Zieclipper. Kept as pure data + pure
// functions here so any route can compute cost before spending, and so the
// docs page can render the exact same numbers straight from this file.
// See docs/credits page for the human-readable version.

export type CreditKind = 'signup_bonus' | 'topup' | 'generate' | 'export' | 'face_track' | 'refund' | 'manual'

// Cost per generate call, scaled by source video length. Matches what we
// promised in the pricing recommendation:
//   ≤ 10 min : 1 kredit
//   10-30 min: 2 kredit
//   30-60 min: 3 kredit
//   > 60 min : 5 kredit
export function creditsForGenerate(durationSeconds: number): number {
  const mins = durationSeconds / 60
  if (mins <= 10) return 1
  if (mins <= 30) return 2
  if (mins <= 60) return 3
  return 5
}

// Optional add-ons paid at export time. Export itself is FREE (rendering
// costs are marginal); we only charge for AI-heavy add-ons.
export const CREDIT_COST = {
  faceTrackingPerExport: 1,   // enabling auto face-track on an export
} as const

// Free-form top-up model: user types any Rupiah amount (>= MIN_TOPUP),
// backend converts at CREDIT_RATE with a progressive bonus for larger
// amounts. Single source of truth used by /api/credits/topup, the settings
// UI's live preview, the pricing page, and the docs page.
export const CREDIT_RATE = 1400          // Rp per 1 credit (base)
export const MIN_TOPUP = 14_000          // Rp — minimum top-up per transaction

// Bonus tiers. The rate here is bonus % ADDED to the base credits. Kept
// as a sorted-ascending array so callers can also render the tier table
// verbatim in the docs & pricing pages.
export const BONUS_TIERS: { minRupiah: number; bonusPct: number }[] = [
  { minRupiah: 14_000,  bonusPct: 0  },
  { minRupiah: 30_000,  bonusPct: 5  },
  { minRupiah: 75_000,  bonusPct: 10 },
  { minRupiah: 150_000, bonusPct: 15 },
  { minRupiah: 300_000, bonusPct: 20 },
]

// Suggested amount chips on the settings page — pure UX aid, not a limit.
// User can still type any other amount.
export const SUGGESTED_AMOUNTS = [14_000, 30_000, 75_000, 150_000, 300_000]

export interface CreditQuote {
  rupiah: number
  base: number         // credits from base rate
  bonus: number        // extra credits from bonus tier
  total: number        // base + bonus
  bonusPct: number     // 0..20
  rupiahPerCredit: number  // effective rate after bonus
}

export function creditsFromRupiah(rupiah: number): CreditQuote {
  const amount = Math.max(0, Math.floor(rupiah))
  const base = Math.floor(amount / CREDIT_RATE)
  // Pick the highest tier the amount qualifies for.
  let bonusPct = 0
  for (const tier of BONUS_TIERS) {
    if (amount >= tier.minRupiah) bonusPct = tier.bonusPct
  }
  const bonus = Math.floor((base * bonusPct) / 100)
  const total = base + bonus
  const rupiahPerCredit = total > 0 ? amount / total : CREDIT_RATE
  return { rupiah: amount, base, bonus, total, bonusPct, rupiahPerCredit }
}

// ─── Server-side spend/add helpers ───────────────────────────────────────
// Both call the SECURITY DEFINER Postgres functions defined in
// supabase/migrations/0003. spend throws with 'insufficient_credits' when
// the balance would go negative; callers should catch and 402 the client.

export async function spendCredits(
  supabase: SupabaseClient,
  amount: number,
  kind: CreditKind,
  description?: string,
  refJobId?: string,
): Promise<number> {
  const { data, error } = await supabase.rpc('spend_credits', {
    p_amount: amount,
    p_kind: kind,
    p_description: description ?? null,
    p_ref_job_id: refJobId ?? null,
  })
  if (error) {
    if (String(error.message || '').includes('insufficient_credits')) {
      throw Object.assign(new Error('insufficient_credits'), { code: 402 })
    }
    throw new Error(`Credit spend failed: ${error.message}`)
  }
  return data as number
}

export async function addCredits(
  supabase: SupabaseClient,
  amount: number,
  kind: CreditKind,
  description?: string,
): Promise<number> {
  const { data, error } = await supabase.rpc('add_credits', {
    p_amount: amount,
    p_kind: kind,
    p_description: description ?? null,
  })
  if (error) throw new Error(`Credit add failed: ${error.message}`)
  return data as number
}

export async function getBalance(supabase: SupabaseClient, userId: string): Promise<number> {
  const { data } = await supabase.from('user_credits').select('balance').eq('user_id', userId).maybeSingle()
  return (data as any)?.balance ?? 0
}
